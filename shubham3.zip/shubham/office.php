<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Inter&display=swap');

    body {
        margin: auto;
        padding: 0px;
        overflow-x: hidden;
        background-repeat: repeat;
        font-family: 'Inter', sans-serif;
    }

    .container {
        width: 100%;
        padding-right: 15px;
        padding-left: 15px;
        margin-right: auto;
        margin-left: auto;
        max-width: 1200px;
    }

    #postList {
        margin-bottom: 20px;
    }

    h1 {
        text-align: center;
        margin: 60px 0 37px 0;
        color: #07a8ff;
        font-size: 33px;
        font-weight: 600;
    }

    .list-item {
        margin: 0 0 37px 0;
        padding: 27px;
        font-size: 17px;
        line-height: 33px;
        color: black;
        border: 0px solid #0e97e5;
        box-shadow: inset 1px 3px 7px 3px #a1dcfe;
    }

    .list-item h4 {
        color: #0074a2;
        margin-left: 10px;
    }

    .load-more {
        margin: 15px 25px;
        cursor: pointer;
        padding: 10px 0;
        text-align: center;
        font-weight: bold;
    }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="office.css">
    <script src="office.js"></script>
    <title>Document</title>
    <script>
    $(document).ready(function() {
        $(window).scroll(function() {
            var filter = document.getElementById("filter").value;
            console.log(filter);
            var lastID = $('.load-more').attr('lastID');
            // var lastID = $('.load-more').attr('lastID');

            if (($('#card-container').height() <= $(window).scrollTop() + $(window).height()) && (
                    lastID !=
                    0)) {
                $.ajax({
                    type: 'POST',
                    url: 'getData.php',
                    //data: 'id=' + lastID,
                    data: {
                        id: lastID,
                        filter: filter,
                    },
                    beforeSend: function() {
                        $('.load-more').show();
                    },
                    success: function(html) {
                        $('.load-more').remove();
                        $('#card-container').append(html);
                    }
                });
            }
        });
    });


    var hovered = false;

    function myFunction() {

        //document.getElementById("countryList").hidden = true;
        $("#countryList").bind("mouseover", function() {
            hovered = true;
            console.log('hii');
        }).bind("mouseout", function() {
            hovered = false;
        });
        // document.getElementsByTagName("body")[0].onclick = () => {
        //     document.getElementById("countryList").hidden = true;
        // }
        $("#country").blur(function() {
            if (!hovered) {
                $("#countryList").hide();
            } else {
                $("#countryList").bind("mouseup", function() {
                    $("#countryList").hide();
                })
            }
        });

    }


    function myFunctionto() {
        document.getElementById("countryList").hidden = false;
        document.getElementById("card-container").setAttribute("display", "none");
    }
    $(document).ready(function() {
        $('#country').keyup(function() {
            var search_type = document.getElementById("searchtype").value;
            var query = $(this).val();
            if (query != '') {
                $.ajax({
                    url: "search2.php",
                    method: "POST",
                    data: {
                        query: query,
                        search_type: search_type
                    },
                    success: function(data) {
                        $('#countryList').fadeIn();
                        $('#countryList').html(data);
                    }
                });
            }
        });
        $(document).on('click', 'li', function() {
            $('#country').val($(this).text());
            console.log($(this).text());
            $('#countryList').fadeOut();
        });
        //$(document).on('click')
    });
    </script>
</head>

<body>
    <nav>
        <h1>
            Office Login
        </h1>
    </nav>
    <!-- <header> -->
    <div class="grid">
        <form method="post">
            <div id="form-search">


                <div>

                    <input type="text" name="country" id="country" class="form-control" placeholder="Enter Country Name"
                        onmouseover="myFunction()" onclick="myFunctionto()" />
                    <select name="searchtype" id="searchtype">
                        <option value="name">name</option>
                        <option value="id">id</option>
                    </select>

                    <select name="filter" id="filter" onchange="this.form.submit()">
                        <option value="">Filter</option>
                        <option value="approved">Approved</option>
                        <option value="not_approved">not-aproved</option>
                    </select>

                </div>
                <div id="countryList"></div>

                <div id="divider"></div>
            </div>
            <div id="card-container">

                <?php
                // Include the database configuration file
                require 'dbConfig.php';

                // Get records from the database
                if (isset($_POST['filter'])) {
                    echo $_POST['filter'] . "bruh";

                    if ($_POST['filter'] == "approved") {
                        echo "1";
                        $query = $db->query("SELECT * FROM students where ExamSection=1 and Office=1 ORDER BY uuid DESC LIMIT 7 ");
                    } else if ($_POST['filter'] == "not_approved") {
                        echo "2";
                        $query = $db->query("SELECT * FROM students where ExamSection=0 and Office=0 ORDER BY uuid DESC LIMIT 7");
                    } else {
                        echo "3";
                        $query = $db->query("SELECT * FROM students ORDER BY uuid DESC LIMIT 7");
                    }
                } else {
                    echo "4";
                    $query = $db->query("SELECT * FROM students ORDER BY uuid DESC LIMIT 7");
                }


                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) {
                        if (isset($_POST['sid'])) {

                            $_SESSION['id'] = $_POST['sid'];
                            echo "<script> location.href='http://localhost/phpintern-main/ExamSection2.php'</script>";
                            //header("Location: http://localhost/projectsnew/ExamSection.php");
                            echo  $_SESSION['id'];
                        }
                        $postID = $row["uuid"];
                ?>

                <div class="card" id="<?php echo $row['sid']; ?>">
                    <div><?php echo $row['sid']; ?></div>
                    <div><?php echo $row['name']; ?></div>
                    <div><?php echo $row['department']; ?></div>
                    <div>Payment Status:</div>
                    <div>Approval Status:</div>
                   
                    <button name="sid" value="<?php echo $row['sid']; ?>"><?php echo $row['uuid']; ?></button>
                </div>



                <?php } ?>
                <script>
                document.getElementById("filter").value = "<?php echo $_POST['filter']; ?>";
                </script>
                <div class="load-more" lastID="<?php echo $postID; ?>" style="display: none;">
                    <img src="loading.gif" />
                </div>
                <?php } ?>








            </div>
        </form>
    </div>

</body>

</html>