<?php
$connect = mysqli_connect("localhost", "root", "", "transcriptDB");
if (isset($_POST["query"]) && $_POST["query"] != "") {
    $search_type = $_POST["search_type"];
    $output = '';
    if ($search_type == "name") {
        $query = "SELECT * FROM students WHERE name LIKE '%" . $_POST["query"] . "%'";
    } else {
        $query = "SELECT * FROM students WHERE sid LIKE '%" . $_POST["query"] . "%'";
    }

    $result = mysqli_query($connect, $query);
    $output = '<ul class="list-unstyled">';

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $we = ($search_type == "name") ? $row["name"] : $row["sid"];
            $output .= '<li>' . $we . '</li>';
        }
    } else {
        $output .= '<li>Country Not Found</li>';
    }
    $output .= '</ul>';
    echo $output;
}