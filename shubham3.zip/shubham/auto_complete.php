<!DOCTYPE html>
<html>

<head>
    <title>Webslesson Tutorial | Autocomplete textbox using jQuery, PHP and MySQL</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <style>
    ul {
        background-color: #eee;
        cursor: pointer;
    }

    li {
        padding: 12px;
    }
    </style>
</head>

<body>
    <br /><br />
    <div class="container" style="width:500px;">

        <input type="text" name="country" id="country" class="form-control" placeholder="Enter Country Name"
            onblur="myFunction()" onfocus="myFunctionto()" />
        <select name="searchtype" id="searchtype">
            <option value="name">name</option>
            <option value="id">id</option>
        </select>
        <div id="countryList"></div>
    </div>
</body>

</html>
<script>
function myFunction() {
    document.getElementById("countryList").hidden = true;
}

function myFunctionto() {
    document.getElementById("countryList").hidden = false;
    document.getElementById("card-container").hidden = true;

}
$(document).ready(function() {
    $('#country').keyup(function() {
        var search_type = document.getElementById("searchtype").value;
        var query = $(this).val();
        if (query != '') {
            $.ajax({
                url: "search2.php",
                method: "POST",
                data: {
                    query: query,
                    search_type: search_type
                },
                success: function(data) {
                    $('#countryList').fadeIn();
                    $('#countryList').html(data);
                }
            });
        }
    });
    $(document).on('click', 'li', function() {
        $('#country').val($(this).text());
        $('#countryList').fadeOut();
    });
});
</script>